'use client'

import confetti from 'canvas-confetti'
import { motion, useAnimationControls } from 'motion/react'
import { useState } from 'react'
import { BIRTHDAY_TARGET, Countdown } from './countdown'
import { GiftBox } from './gift-box'
import { Starfield } from './starfield'

const PROMPT = 'Mèo à, ấn vào đây đi...'
const COLORS = ['#ffb3c7', '#f9d5dc', '#fff7f0', '#f3c98b', '#e8899e', '#ffffff']

function burstConfetti() {
  const heart = confetti.shapeFromPath({
    path: 'M12 21s-7.5-4.6-10-9.3C.2 8.2 2.3 4 6.3 4c2.2 0 3.7 1.3 4.7 2.7C12 5.3 13.5 4 15.7 4c4 0 6.1 4.2 4.3 7.7C19.5 16.4 12 21 12 21z',
  })
  const base = { colors: COLORS, ticks: 260, zIndex: 60, disableForReducedMotion: true }
  confetti({ ...base, particleCount: 140, spread: 360, startVelocity: 42, origin: { x: 0.5, y: 0.5 }, scalar: 1.1 })
  confetti({ ...base, particleCount: 40, spread: 360, startVelocity: 30, origin: { x: 0.5, y: 0.5 }, shapes: [heart], scalar: 2 })
  setTimeout(() => {
    confetti({ ...base, particleCount: 80, angle: 60, spread: 70, startVelocity: 60, origin: { x: 0, y: 0.9 } })
    confetti({ ...base, particleCount: 80, angle: 120, spread: 70, startVelocity: 60, origin: { x: 1, y: 0.9 } })
  }, 220)
  setTimeout(() => {
    confetti({ ...base, particleCount: 60, spread: 160, startVelocity: 25, origin: { x: 0.5, y: 0 }, gravity: 0.6, shapes: [heart], scalar: 1.6 })
  }, 500)
}

export function IntroScene({ onOpen, onComplete }: { onOpen: () => void; onComplete: () => void }) {
  const [opened, setOpened] = useState(false)
  const [ready, setReady] = useState(false)
  const controls = useAnimationControls()
  const shake = useAnimationControls()

  function handleReady(justReached: boolean) {
    setReady(true)
    if (!justReached) return
    navigator.vibrate?.([120, 60, 120])
    shake.start({
      x: [0, -10, 10, -8, 8, -5, 5, -2, 0],
      rotate: [0, -0.6, 0.6, -0.4, 0.4, 0],
      transition: { duration: 0.7, ease: 'easeInOut' },
    })
  }

  async function handleOpen() {
    // Chặn mở quà trước đúng 00:00 ngày 26/10/2026 (giờ Việt Nam),
    // kể cả khi trạng thái đếm ngược chưa kịp cập nhật.
    if (opened || !ready || Date.now() < BIRTHDAY_TARGET) return
    setOpened(true)
    onOpen()
    await controls.start({ scale: [1, 0.86, 1.18], transition: { duration: 0.35, ease: 'easeOut' } })
    burstConfetti()
    await controls.start({ scale: 3.2, opacity: 0, filter: 'blur(8px)', transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] } })
    setTimeout(onComplete, 650)
  }

  return (
    <motion.section
      animate={shake}
      className="relative flex min-h-dvh flex-col items-center justify-center overflow-hidden px-6 py-8"
    >
      <Starfield />

      <motion.div
        initial={{ opacity: 0, y: -16 }}
        animate={opened ? { opacity: 0, y: -24 } : { opacity: 1, y: 0 }}
        transition={{ duration: opened ? 0.3 : 0.8, delay: opened ? 0 : 0.1 }}
        className="relative z-10 mb-6"
      >
        <Countdown ready={ready} onReady={handleReady} />
      </motion.div>

      <motion.p
        aria-hidden
        className="neon-text relative z-10 mb-2 text-center font-script text-4xl font-bold"
        initial="hidden"
        animate={opened ? 'gone' : 'visible'}
        variants={{
          hidden: {},
          visible: { transition: { staggerChildren: 0.06, delayChildren: 0.4 } },
          gone: { opacity: 0, y: -20, transition: { duration: 0.3 } },
        }}
      >
        {Array.from(PROMPT).map((char, i) => (
          <motion.span
            key={i}
            className="inline-block whitespace-pre"
            variants={{ hidden: { opacity: 0, y: 12, filter: 'blur(6px)' }, visible: { opacity: 1, y: 0, filter: 'blur(0px)' } }}
          >
            {char}
          </motion.span>
        ))}
      </motion.p>

      <motion.button
        type="button"
        onClick={handleOpen}
        disabled={!ready || opened || Date.now() < BIRTHDAY_TARGET}
        aria-label={PROMPT}
        aria-disabled={!ready || opened || Date.now() < BIRTHDAY_TARGET}
        className="relative z-10 cursor-pointer rounded-full outline-none focus-visible:ring-4 focus-visible:ring-rose/60"
        initial={{ opacity: 0, scale: 0.6, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ type: 'spring', stiffness: 120, damping: 14, delay: 0.2 }}
        whileHover={ready && !opened ? { scale: 1.05 } : undefined}
        whileTap={ready && !opened ? { scale: 0.94 } : undefined}
      >
        <motion.div animate={controls}>
          {ready && !opened && (
            <motion.div
              aria-hidden
              className="gift-ready-glow absolute -inset-10 rounded-full"
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1.2, ease: 'easeOut' }}
            />
          )}
          <div aria-hidden className="glow-breathe absolute inset-4 rounded-full bg-[radial-gradient(circle,#ff8fb1_0%,rgba(255,143,177,0.35)_40%,transparent_70%)] blur-2xl" />
          <div className={opened ? '' : 'gift-pulse'}>
            <GiftBox />
          </div>
          <div aria-hidden className="mx-auto -mt-4 h-5 w-40 rounded-[50%] bg-black/40 blur-md" />
        </motion.div>
      </motion.button>

      <motion.p
        className={`relative z-10 mt-6 text-sm tracking-[0.3em] uppercase transition-colors duration-700 ${ready ? 'text-blush' : 'text-white/50'}`}
        initial={{ opacity: 0 }}
        animate={{ opacity: opened ? 0 : 1 }}
        transition={{ delay: opened ? 0 : 2 }}
      >
        {opened ? '' : ready ? 'Quà đã sẵn sàng, chạm để mở' : 'Đợi đến 00:00 để mở quà nhé'}
      </motion.p>

      {opened && (
        <motion.div
          aria-hidden
          className="pointer-events-none absolute inset-0 z-20 bg-[radial-gradient(circle,#fff7f0_0%,#ffd6e2_45%,transparent_75%)]"
          initial={{ opacity: 0, scale: 0.2 }}
          animate={{ opacity: [0, 1, 0.9], scale: [0.2, 1.4, 3] }}
          transition={{ duration: 1.3, delay: 0.3, ease: 'easeOut' }}
        />
      )}
    </motion.section>
  )
}
